import java.util.*;
import java.util.stream.Collectors;

public class MultiSet {
    private final Object [] elements; // Elemente der Multimenge
    public MultiSet(int n){
        elements = new Object[n];
    }
    public boolean add(Object x){
        if(x == null) {
            return false;
        }
        for (int i = 0; i < elements.length; i++) {
            if (elements[i] == null) {
                elements[i] = x;
                return true;
            }
        }
        return false;
    }
    public int count(Object x){
        int count = 0;
        for (Object element : elements) {
            if (element == x) {
                count++;
            }
        }
        return count;
    }
    @Override
    public String toString() {
        return Arrays.stream(elements)
                .filter(Objects::nonNull)
                .map(Object::toString)
                .collect(Collectors.joining(",", "{", "}"));
    }
    @Override
    public boolean equals(Object other){
        if (!(other instanceof MultiSet that)) return false;
        return new HashSet<>(Arrays.asList(this.elements)).containsAll(Arrays.asList(that.elements)) && new HashSet<>(Arrays.asList(that.elements)).containsAll(Arrays.asList(this.elements));    }
    @Override
    public int hashCode(){
          int hash = 0;
          for (Object element : elements) {
                hash += Objects.hashCode(element);
          }
          return hash;
    }
}