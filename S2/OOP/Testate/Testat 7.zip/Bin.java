public abstract class Bin extends Expr{
    protected Expr left;
    protected Expr right;

    public Bin(Expr l, Expr r) {
        this.left = l;
        this.right = r;
    }

    protected abstract double combine(double l, double r);

    protected abstract String oper();

    @Override
    public double compute(){
        return combine(left.compute(), right.compute());
    }

    @Override
    public String toString() {
        return "(" + left.toString() + oper() + right.toString() + ")";
    }

    @Override
    public boolean equals(Object other) {
        if (other instanceof Bin b) {
            return left.equals(b.left) && right.equals(b.right);
        }
        return false;
    }
}
