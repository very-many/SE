public abstract class Expr {
    public abstract double compute();
}
