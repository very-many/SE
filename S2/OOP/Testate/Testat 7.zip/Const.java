public class Const  extends Expr{
    private final double value;

    public Const(double value) {
        this.value = value;
    }

    public double compute() {
        return value;
    }

    @Override
    public String toString() {
        return Double.toString(value);
    }

    @Override
    public boolean equals(Object other) {
        if (other instanceof Const) {
            Const c = (Const) other;
            return value == c.value;
        }
        return false;
    }
}
