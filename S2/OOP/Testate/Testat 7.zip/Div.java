public class Div extends Bin{

    public Div(Expr l, Expr r) {
        super(l, r);
    }
    @Override
    protected double combine(double l, double r) {
        if(r != 0){
            return l / r;
        }
        else {
            throw new ArithmeticException("Division by zero");
        }

    }

    @Override
    protected String oper() {
        return "/";
    }
}
