public class StringSet {
    private final int size;
    private final String[] stringset;

    public StringSet(int n){
        size = n;
        stringset = new String[n];
    }

    public StringSet(int n, String s){
        size = n;
        stringset = new String[n];
        insert(s);
    }

    public int capacity(){
        return size;
    }

    public int card(){
        int card = 0;
        for (int i = 0; i < size; i++){
            if (stringset[i] != null){
                card++;
            }
        }
        return card;
    }
    public void print(){
        System.out.print("{");
        for (int i = 0; i < size; i++){
            if (stringset[i] != null){
                if (i+1 == size || stringset[i+1] == null) {
                    System.out.print(" " + stringset[i]);
                } else {
                    System.out.print(" " + stringset[i] + ",");
                }
            }
        }
        System.out.print(" }");
    }
    public boolean contains(String s){
        for (int i = 0; i < size; i++){
            if (stringset[i] != null && stringset[i].equals(s)){
                return true;
            }
        }
        return false;
    }
    public boolean insert(String s){
        if (s == null){
            return false;
        }
        for (int i = 0; i < size; i++){
            if (stringset[i] == null){
                stringset[i] = s;
                return true;
            }
        }
        return false;
    }
    public boolean remove(String s){
        for (int i = 0; i < size; i++){
            if (stringset[i] != null && stringset[i].equals(s)){
                stringset[i] = null;
                return true;
            }
        }
        return false;
    }
    public static StringSet intersection(StringSet s, StringSet t){
        StringSet intersection = new StringSet(s.size);
        for (int i = 0; i < s.size; i++){
            if (s.stringset[i] != null && t.contains(s.stringset[i])){
                intersection.insert(s.stringset[i]);
            }
        }
        return intersection;
    }
}

