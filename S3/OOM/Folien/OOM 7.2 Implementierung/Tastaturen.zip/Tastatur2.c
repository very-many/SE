/* Implementierung des Zustandsautomaten Beispiel 2, S. 7-83 in C */
/* Voraussetzungen: Siehe S. 7-81 */

/* Qualitative Zust�nde */
/* (hier Gro�-Schreibung der Zusatandsnamen, da default ein reserviertes Wort ist. */
/* Kein Endzustand! */
enum Zustand {Default, Caps_Locked};

/* Zustandsvariable */
enum Zustand Z = Default;

/* Variablen f�r quantitative Zust�nde */
int k; /* Zum einlesen von Tasten */

do {
	switch(Z) {
		case Default: 
			/* Verarbeitung im Zustand: interne Transition */
			k=getKey();
			if(k!=CAPS_LOCK) send_lower_case_scan_code(k);
			/* Berechnung des Folgezustands: */
			if (k==CAPS_LOCK) // nur ein �bergang ist zu pr�fen!
			{ 
				Z = Caps_Locked;
			} 
			break;
		case Caps_Locked:
			/* Verarbeitung im Zustand: interne Transition */
			k=getKey();
			if(k!=CAPS_LOCK) send_upper_case_scan_code(k);
			/* Berechnung des Folgezustands: */
			if (k==CAPS_LOCK) // nur ein �bergang ist zu pr�fen!
			{ 
				Z = Default; 
			} 
	} while 1;
