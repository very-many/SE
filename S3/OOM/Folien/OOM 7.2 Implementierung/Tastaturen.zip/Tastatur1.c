/* Implementierung des Zustandsautomaten Beispiel 1, S. 7-82 in C */
/* Voraussetzungen: Siehe S. 7-81 */

/* Qualitative Zust�nde */
/* (hier Gro�-Schreibung der Zusatandsnamen, da default ein reserviertes Wort ist. */
/* Kein Endzustand! */
enum Zustand {Default, Caps_Locked};

/* Zustandsvariable */
enum Zustand Z = Default;

/* Variablen f�r quantitative Zust�nde */
int k; /* Zum einlesen von Tasten */

do {
	switch(Z) {
		case Default: 
			/* Keine Verarbeitung im Zustand */
			/* Berechnung des Folgezustands: */
			k=get_key();
			if (k==CAPS_LOCK)
			{ 
				Z = Caps_Locked; 
			} 
			else /* k==ANY_KEY */
			{
				send_lower_case_scan_code(k); /* �bergangsaktivit�t */
				/* Z bleibt unver�ndert */
			}
			break;
		case Caps_Locked:
			/* Keine Verarbeitung im Zustand */
			/* Berechnung des Folgezustands: */
			k=get_key();
			if (k==CAPS_LOCK)
			{ 
				Z = Default; 
			} 
			else /* k==ANY_KEY */
			{
				send_upper_case_scan_code(k); /* �bergangsaktivit�t */
				/* Z bleibt unver�ndert */
			}
	} while 1;
