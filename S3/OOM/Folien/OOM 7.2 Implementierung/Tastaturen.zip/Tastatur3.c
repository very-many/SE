/* Implementierung des Zustandsautomaten Beispiel 3, S. 7-84 in C */
/* Voraussetzungen: Siehe S. 7-81 */

/* Qualitative Zust�nde */
/* (hier Gro�-Schreibung der Zusatandsnamen, da default ein reserviertes Wort ist. */
enum Zustand {Default, Caps_Locked, ende};

/* Zustandsvariable */
enum Zustand Z = Default;

/* Variablen f�r quantitative Zust�nde */
int k; /* Zum einlesen von Tasten */
int keyCount = 1000; /* Tastenz�hler */

do {
	switch(Z) {
		case Default: 
			/* Keine Verarbeitung im Zustand */
			/* Berechnung des Folgezustands: */
			k=get_key();
			if (k==CAPS_LOCK)
			{ 
				Z = Caps_Locked; 
			} 
			else /* k==ANY_KEY */
			{
				keyCount--; /* �bergangsaktivit�t */
				/* �bergang �ber Entscheidung*/
				if (keyCount == 0)
				{
					Z = Ende;
				}
				else
				{
					send_lower_case_scan_code(k); /* �bergangsaktivit�t */
					/* Z bleibt unver�ndert */
				}
			}
			break;
		case Caps_Locked:
			/* Keine Verarbeitung im Zustand */
			/* Berechnung des Folgezustands: */
			k=get_key();
			if (k==CAPS_LOCK)
			{ 
				Z = Default; 
			} 
			else /* k=ANY_KEY */
			{	
				keyCount--; /* �bergangsaktivit�t */
				/* �bergang �ber Entscheidung*/
				if (keyCount == 0)
				{
					Z = Ende;
				}
				else
				{
					send_upper_case_scan_code(k); /* �bergangsaktivit�t */
					/* Z bleibt unver�ndert */
				}
			}
	} while (Z != Ende);
