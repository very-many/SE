/* Uhr.h */

#ifndef UHR_H
#define UHR_H

#include "Zeit.h"

/* Klasse Uhr */

class Uhr {

	int std;
	int min;
	int sek;

	Zeit * zeitgeber; // Implementierung der Assoziation

public:

	Uhr();

	void zeitZeigen();
	void stdZeigen();
	void minZeigen();
	// void sekZeigen();

	void inc();	
	void incStd();
	void incMin();
	// void incSek();

	void run();

};

#endif 

