// Digitaluhr.cpp : Definiert den Einstiegspunkt f�r die Konsolenanwendung.
//

#include "Uhr.h"


int main(int argc, char* argv[])
{
	Uhr * uhr = new Uhr();
	uhr -> run();
	return 0;
}

