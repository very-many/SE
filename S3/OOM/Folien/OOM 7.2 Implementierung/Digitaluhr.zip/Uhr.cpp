/* Uhr.cpp */

#include <iostream>
#include <iomanip>
#include <conio.h> /* F�r _getch() und _kbhit() */


#include "Uhr.h"
#include "Zeit.h"

using namespace std;


void Uhr::zeitZeigen()
{	// Uhrzeit anzeigen
	cout << setw(2)  << setfill('0') << std << ":" 
		 << setw(2)  << setfill('0') << min << ":" 
		 << setw(2)  << setfill('0')<< sek << endl;
}


void Uhr::minZeigen()
{	// Nur Minuten anzeigen	
	cout << "  :" << setw(2)  << setfill('0') << min << endl;
}


void Uhr::stdZeigen()
{	// Nur Stunden anzeigen
	cout << setw(2) << setfill('0') << std <<":  " <<  endl;
}

void Uhr::incStd()
{
	this->std++;
	if (this->std==24) this->std=0;
}

void Uhr::incMin()
{
	this->min++;
	if (this->min==60) this->min=0;
}

void Uhr::inc()
{
	this->sek++;
	
	if(this->sek==60) /* eine Minute voll */
	{ 
		this->min++; this->sek= 0;
		if (this->min==60) /* eine Stunde voll */
		{
			this->std++; this->min=0;
			if (this->std==24) /* Ein Tag voll */
			{
				this->std=0;
			}
		}
	}
	

}


Uhr::Uhr()
{
	this->zeitgeber = new Zeit();
	this->std=this->min=this->sek=0;
}


void Uhr::run()
{
	/* Qualitative Zust�nde */
	enum Zustand {Anzeige,StdStellen,MinStellen, ende};

	/* Quantitativer Zustand */
	int tick;

	/* Zum Einlesen der Tastaturereignisse */
	char taste;

	/* Zum Warten auf Ereignisse */
	int feuert;

	/* Start-�bergang */
	enum Zustand Z = Anzeige;

	do {
		feuert = 0; 
		switch(Z)
		{
		case Anzeige:

			tick = zeitgeber->getSek(); /* entry-Aktion */
			
			zeitZeigen(); /* do-Aktivit�t */

			/* �bergang bestimmen */
			while (!feuert)
			{
				if (_kbhit()) 
				{ 
					taste = _getch(); /* Falls Taste gedr�ckt wurde, Taste lesen */
					if (taste == 'a')
					{
						feuert = 1;
						Z = StdStellen; 
					}
					else if (taste == 'z')
					{
						feuert = 1;
						Z = ende;
					}
				}
				else if (tick != zeitgeber->getSek()) /* Sekunden ver�ndert? */
				{
					feuert = 1;
					inc(); /* �bergangsaktion */
					/* Z unver�ndert */
				}
			}
			break;

		case StdStellen:

			/* Verarbeitung im Zustand StdStellen */
			stdZeigen();

			/* �bergang bestimmen - Es muss eine Taste gedr�ckt werden */
			taste = _getch();
			
			if(taste == 'a')
			{
				Z = MinStellen;
			}
			else if(taste == 'b')
			{
				incStd(); /* �bergangsaktion */
				/* Zustand unver�ndert */
			}
			break;

		case MinStellen:

			/* Verarbeitung im Zustand StdStellen */
			minZeigen();

			/* �bergang bestimmen - Es muss eine Taste gedr�ckt werden */
			taste = _getch();
			
			if(taste == 'a')
			{
				Z = Anzeige;
			}
			else if(taste == 'b')
			{
				incMin(); /* �bergangsaktion */
				/* Zustand unver�ndert */
			}
			break;

		} /* end-switch */
	} while (Z != ende);
	
} 
