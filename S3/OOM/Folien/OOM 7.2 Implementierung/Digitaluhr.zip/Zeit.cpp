/* Zeit.cpp */

#include <ctime>
#include "Zeit.h"


void Zeit::update() 
{ // aktualisiert das std,- min- und sek-Attribut des Zeit-Objekts
  // mit Hilfe der Zeit-Funktionen aus <stdlib.h>
  
	// Die Funktion "time()" liefert die aktuelle Uhrzeit als "globale Zeit",
	// d.h. als ganze Zahl (=Anzahl der seit 1.1.70 vergangenen Sekunden)
	// Der Typ "time_t" ist eine gro�e ganze Zahl (64 bit)
	time_t globaleZeit;
	time(&globaleZeit);
	
	// Die Funktion "localtime()" berechnet aus einer gloabalen Zeit eine "lokale Zeit"
	// d.h. mit Stunden, Minuten und Sekunde.
	// Die Struktur "tm" enth�lt Attribute tm_hour, tm_min und tm_sec

	struct tm *lokaleZeit;
	lokaleZeit = localtime(&globaleZeit);

	this->std = lokaleZeit->tm_hour;
	this->min = lokaleZeit->tm_min;
	this->sek = lokaleZeit->tm_sec;
}



int Zeit::getStd()
{ this->update();
  return this->std;
}

int Zeit::getMin()
{ this->update();
  return this->min;
}

int Zeit::getSek()
{ this->update();
  return this->sek;
}
