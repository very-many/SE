/* Zeit.h */

#ifndef ZEIT_H
#define ZEIT_H




/* Klasse Zeit */

class Zeit {

private:
	int std;
	int min;
	int sek;

	void update(); // Aktualisiert die Werte von std und min aufgrund der aktuellen Rechnerzeit

public:  /* �ffentliche Mehtoden von Zeit */

	// Zeit(); 
	int getStd();  
	int getMin(); 
	int getSek();
	
};



#endif