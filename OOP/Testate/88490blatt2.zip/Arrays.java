
class Arrays {
    // Reihe a elementweise in einer Zeile ausgeben.
    public static void print (double [] a) {
        for (double v : a) {
            System.out.print(v + " ");
        }
        System.out.println();
    }
    // Reihenfolge der Elemente der Reihe a umdrehen.
    public static void mirror (double [] a) {
        double temp = 0;
        for (int i = 0; i < a.length / 2; i++) {
            temp = a[i];
            a[i] = a[a.length - i - 1];
            a[a.length - i - 1] = temp;
        }
    }
    // Rotation der Reihe a um k Positionen nach rechts
    // als neue Reihe liefern.
    public static double [] rotate (double [] a, int k) {
        double[] rotatedArray = new double[a.length];
        for (int i = 0; i < a.length; i++) {
            int newPos = (i + k) % a.length;
            rotatedArray[newPos] = a[i];
        }
        return rotatedArray;
    }
    // Elemente der Reihen a und b per "Reißverschlussverfahren"
    // zu einer neuen Reihe zusammenfügen.
    public static double [] zip (double [] a, double [] b) {
        int maxLength = a.length > b.length ? a.length : b.length; //Math wäre eine java bib Anweisung, also mach ich es so.
        double[] zippedArray = new double[a.length + b.length];
        int index = 0;

        for (int i = 0; i < maxLength; i++) {
            if (i < a.length) {
                zippedArray[index++] = a[i];
            }
            if (i < b.length) {
                zippedArray[index++] = b[i];
            }
        }
        return zippedArray;
    }
    // Test.
    public static void main (String [] args) {
        // Reihen a und b durch Reiheninitialisierer konstruieren.
        // Zum Beispiel:
        double [] a = { 3, 7, 9 }, b = { 2, 8, 6, 4, 10 };
        System.out.println("mirror(a)");
        mirror(a); print(a);

        System.out.println("rotate(b, 2)");
        print(rotate(b, 2));

        System.out.println("zip(a, b)");
        print(zip(a, b));

    }
}