public class Line {
    Point begin;
    Point end;
    public Line(Point start, Point stop){
        begin = start;
        end = stop;
    }
    public Line(double x1, double y1, double x2, double y2){
        begin = new Point(x1, y1);
        end = new Point(x2, y2);
    }

    public double length(){
        double x = Math.abs(end.getX()-begin.getX());
        double y = Math.abs(end.getY()- begin.getY());

        return Math.sqrt(x*x+y*y);
    }
    public Point getBegin() {
        return begin;
    }

    public Point getEnd() {
        return end;
    }
}
