public class Point {
    double objX;
    double objY;
    public Point(){
        objX = 0;
        objY = 0;
    }
    public Point(double x, double y){
        objX = x;
        objY = y;
    }

    public void move(double x, double y){
        objX += x;
        objY += y;
    }

    public void print(){
        System.out.println("("+objX+", "+objY+")");
    }

    public double getX(){
        return objX;
    }

    public double getY() {
        return objY;
    }
}
