public class Test {
    public static void main(String[] args){
        // Punkt p1 mit x-Koordinate 1.5 und y-Koordinate -3.7 erzeugen.
        Point p1 = new Point(1.5, -3.7);
        // Punkt p2 mit x- und y-Koordinate 0 erzeugen.
        Point p2 = new Point();
        // Koordinaten von p1 abfragen und ausgeben.
        System.out.println("x-Koordinate: " + p1.getX());
        System.out.println("y-Koordinate: " + p1.getY());
        // Punkt p1 in x-Richtung um 2.5 und in y-Richtung um 0.7 verschieben.
        p1.move(2.5, 0.7);
        // Punkt p1 in einer Zeile ausgeben.
        p1.print();
        // Ausgabe muss lauten: (4.0, -3.0)

        // Linie mit Anfangspunkt p1 und Endpunkt p2 erzeugen.
        Line ln = new Line(p1, p2);
        // Anfangs- und Endpunkt von ln abfragen und ausgeben.
        ln.getBegin().print(); // Ausgabe: (4.0, -3.0)
        ln.getEnd().print(); // Ausgabe: (0.0, 0.0)
        // Länge von ln berechnen und ausgeben.
        System.out.println("Länge: " + ln.length());
        // Ausgabe: 5.0
        // Linie mit Anfangspunkt (4.0, -3.0) und Endpunkt (0.0, 0.0) erzeugen.
        ln = new Line(-4.0, -3.0, -4.0, 3.0);
        // Anfangs- und Endpunkt von ln abfragen und ausgeben.
        ln.getBegin().print(); // Ausgabe: (4.0, -3.0)
        ln.getEnd().print(); // Ausgabe: (0.0, 0.0)
        // Länge von ln berechnen und ausgeben.
        System.out.println("Länge: " + ln.length());
        // Ausgabe: 5.0
    }
}