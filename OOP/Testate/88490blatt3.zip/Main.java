public class Main {

    public static void main(String[] args) {
        int [][] test = pascal(5);
        print(test);
        int [][] test2 = new int[0][0];
        print(test2);
        if(isPalindrome("lagerregal")){
            System.out.println(toLower(reverse("Bingo Bango Bongo")));
        }
        else {
            System.out.println(toLower("Anton"));
        }

    }

    public static void print (int[][] array){
        for (int[] ints : array) {
            for (int anInt : ints) {
                if (anInt != 0) {
                    System.out.print(anInt + " ");
                }
            }
            System.out.println();
        }
    }

    public static int[][] pascal(int n){
        //n++; //damit es bei immer eine Zeile Mehr hat, bzw. bei 0 beginnt.
        int [][] pascalArray = new int[n][n];

        for (int i = 0; i<n; i++){
            for (int j = 0; j <= i; j++){
                if (j == 0 || j == i){
                    pascalArray[i][j] = 1;
                }
                else{
                    pascalArray[i][j]=pascalArray[i-1][j-1]+pascalArray[i-1][j];
                }
            }
        }
        return pascalArray;
    }

    public static String reverse(String string){
        return reverse(string, string.length()-1);
    }

    public static String reverse(String string, int index){
        if (string.length()==0){
            return "";
        }
        if(index == 0){
            return string.charAt(0) + "";
        }
        char letter = string.charAt(index);
        return letter + reverse(string, index -1);
    }

    public static boolean isPalindrome(String kette){
        if (kette.length() == 0){
            return false;
        }
        String kette2 = reverse(kette);
        for (int i = 0; i < kette.length(); i++){
            if (kette.charAt(i) != kette2.charAt(i)){
                return false;
            }
        }
        return true;
    }

    public static String toLower(String string){
        if (string.length() == 0){
            return "";
        }
        String string2 = "";
        char [] array = new char[string.length()];

        for (int j = 0; j < string.length(); j++){
            array[j] = string.charAt(j);
            if (array[j] >= 'A' && array[j] <= 'Z'){
                array[j] = (char) (array[j] + 32);
            }
            string2 += array[j];
        }
        return string2;
    }
}